#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"
#include "DHT11.h"
#include "Buzzer.h"
#include "AD.h"
#include "esp.h"
#include "LED.h"
#include "jdq.h"
#define  YUN_CONNECT 1 

void YUN_Transmit(int cnt);

float Voltage; 
float VoltageADValue;
uint8_t temperature;
uint8_t humidity;
uint8_t Buzzer=0;
uint8_t LED=0;
uint8_t relay1=1;
uint8_t relay2=1;
int cnt;  
/*阈值变量*/
uint16_t temp_setting=35;
uint16_t humi_setting=85;

void Init(void)
{
    OLED_Init();
    OLED_ShowString(2,24,"UPS",OLED_8X16);
    OLED_ShowChinese(28,24,"电池安全监测");
    OLED_Update();
    DHT11_Init();
    relay1_init();
	relay2_init();
    Buzzer_Init();
    LED_Init();
    AD_Init();
    esp_Init();
}

int main(void)
{
  Init();
  OLED_Clear();
  OLED_ShowChinese(0,0,"温度：");
  OLED_ShowChinese(0,24,"湿度：");
  OLED_ShowChinese(0,48,"电压：");
  OLED_ShowString(64,0,"C",OLED_8X16);
  OLED_ShowString(64,24,"%RH",OLED_8X16);
  OLED_ShowString(52,48,".  V",OLED_8X16);
  OLED_Update();
  while(1)
  {
    cnt++;
    DHT11_Read_Data(&temperature, &humidity);//温湿度
    OLED_ShowNum(42, 0, temperature, 2,OLED_8X16);
    OLED_ShowNum(42, 24, humidity, 2,OLED_8X16);
    VoltageADValue = AD_GetValue(ADC_Channel_1);//电压值 
    Voltage = VoltageADValue * (3.3 / 4095.0) * (4.4);
    OLED_ShowNum(42, 48, (int)Voltage, 1,OLED_8X16);
    OLED_ShowNum(58, 48, (uint16_t)(Voltage * 100) % 100, 2,OLED_8X16);
    OLED_Update();
	  if(temperature >= temp_setting || humidity >= humi_setting || Voltage <= 0.7) 
    {
		LED_ON();
        Buzzer_ON(); 
		relay2_OFF();
    }
    else
    {
		LED_OFF();
        Buzzer_OFF(); 
		relay2_ON();
    }
      YUN_Transmit(cnt);

	  if(relay1==0)
      {relay1_OFF();}
	  if(relay1==1)
      {relay1_ON();}

  }

}

void YUN_Transmit(int cnt) //上传数据
{
#if YUN_CONNECT
        if(cnt%350==0)
        {
        esp_pub();
        }
#endif
}
