#ifndef __JDQ_H
#define __JDQ_H

void relay1_init(void);
void relay2_init(void);
void relay1_ON(void);
void relay1_OFF(void);
void relay2_ON(void);
void relay2_OFF(void);
#endif


