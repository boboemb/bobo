#include "stm32f10x.h"
#include "Serial.h"
#include "Delay.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>

extern uint8_t temperature;
extern uint8_t humidity; 
extern uint16_t temp_setting;
extern uint16_t humi_setting;
extern uint8_t Buzzer;
extern uint8_t LED;
extern uint8_t relay1;
extern uint8_t relay2;
extern float Voltage;

extern char RECS[260];

const char* wifi=".";
const char* wifipassword=".";
const char* username=".";
const char* password=".";
const char* Url=".";
const char* func1="temperature";
const char* func2="humidity";
const char* func3="Buzzer";
const char* func4="LED";
const char* func5="U";
const char* func6="relay2";
const char* func7="relay1";
const char* func8="temp_setting";
const char* func9="humi_setting";

void esp_Init(void)//连接
{
Serial_Init();
Serial_Printf("AT+RST\r\n");//复位
Delay_ms(500);
Serial_Printf("AT+CWMODE=1\r\n");//Station模式（客户端模式）
Delay_ms(500);
Serial_Printf("AT+CWJAP=\"%s\",\"%s\"\r\n",wifi,wifipassword);
Delay_ms(1500);
Serial_Printf("AT+MQTTUSERCFG=0,1,\"thingscloud\",\"%s\",\"%s\",0,0,\"\"\r\n",username,password);
Delay_ms(2000);
Serial_Printf("AT+MQTTCONN=0,\"%s\",1883,1\r\n",Url);
Delay_ms(2000);
Serial_Printf("AT+MQTTSUB=0,\"attributes/push\",1\r\n");
Delay_ms(1000);//下发指令
}
void esp_pub(void)
{
printf("AT+MQTTPUB=0,\"attributes\",\"{\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%f\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d\\}\",0,0\r\n",func1,temperature,func2,humidity,func5,Voltage,func6,relay2,func7,relay1,func3,Buzzer,func4,LED,func8,temp_setting,func9,humi_setting);
Delay_ms(1000);//上报指令
}
void CommandAnalyse(void)
{
    if(strncmp(RECS,"+MQTTSUBRECV:",13)==0)
    {
      uint8_t i=0;
      while(RECS[i++] != '\0')             
      {
        if(strncmp((RECS+i),func7,6)==0)  
        {
        while(RECS[i++] != ':');
        relay1=RECS[i]-'0';
        }
        if(strncmp((RECS+i),func8,12)==0)    //temp_setting   判断是个位数还是两位数
        {
        while(RECS[i++] != ':');// isdigit检测字符是否为数字   判断是个位数还是两位数
        if(isdigit(RECS[i+1]))    temp_setting=(RECS[i]-'0')*10+RECS[i+1]-'0'; //是两位数
        else   humi_setting=RECS[i]-'0';
        }
        if(strncmp((RECS+i),func9,12)==0)  //humi_setting  
        {
        while(RECS[i++] != ':');// isdigit检测字符是否为数字   判断是个位数还是两位数
        if(isdigit(RECS[i+1]))    humi_setting=(RECS[i]-'0')*10+RECS[i+1]-'0'; //是两位数
        else   humi_setting=RECS[i]-'0';
        }
      }
    }
}

