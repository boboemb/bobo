#include "stm32f10x.h"                  // Device header
#include "jdq.h"

void relay1_init(void)
{
  GPIO_InitTypeDef     GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}       

void relay2_init(void)
{
  GPIO_InitTypeDef     GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
  GPIO_Init(GPIOA, &GPIO_InitStructure);
}  
 
void relay1_ON(void)
{
  GPIO_SetBits(GPIOB,GPIO_Pin_0);
}
 
void relay1_OFF(void)
{ 
  GPIO_ResetBits(GPIOB,GPIO_Pin_0);
}

void relay2_ON(void)
{
  GPIO_SetBits(GPIOA,GPIO_Pin_2);
}
 
void relay2_OFF(void)
{ 
  GPIO_ResetBits(GPIOA,GPIO_Pin_2);
}
